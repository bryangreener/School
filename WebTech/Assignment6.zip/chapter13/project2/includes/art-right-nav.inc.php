<div class="panel panel-info">
   <div class="panel-heading">
      <h3 class="panel-title">Popular Artists</h3>
   </div>
   <div class="panel-body">
      <ul class="nav nav-pills nav-stacked">
         <li><a href="display-artist.php?id=101">Caravaggio</a></li>
         <li><a href="display-artist.php?id=21">Cezanne</a></li>
         <li><a href="display-artist.php?id=2">Matisse</a></li>
         <li><a href="display-artist.php?id=98">Michelangelo</a></li>
         <li><a href="display-artist.php?id=1">Picasso</a></li>
         <li><a href="display-artist.php?id=99">Raphael</a></li>
         <li><a href="display-artist.php?id=19">Van Gogh</a></li>
      </ul>
   </div>
</div>        

<div class="panel panel-info">
   <div class="panel-heading">
      <h3 class="panel-title">Popular Genres</h3>
   </div>
   <div class="panel-body">
      <ul class="nav nav-pills nav-stacked">
         <li><a href="#">Baroque</a></li>
         <li><a href="#">Cubism</a></li>
         <li><a href="#">Impressionism</a></li>
         <li><a href="#">Renaissance</a></li>
      </ul>
   </div>
</div>