<?php



?>

<div class="panel panel-primary">
   <div class="panel-heading">
      <h3 class="panel-title">Cart </h3>
   </div>
   <div class="panel-body">  
      <?php
      

         
         /*
         
         This will have to be uncommented and the appropriate cart data placed into it

            <div class="media">
              <a class="pull-left" href="#">
                <img class="media-object" src="images/art/works/tiny/.jpg" alt="" width="32">
              </a>
              <div class="media-body">
                <p class="cartText"><a href="display-art-work.php?id="></a></p>
              </div>
            </div> 
            
         

      
         <strong class="cartText">Subtotal: <span class="text-warning">$</span></strong>
         <div>
            <a href="chapter13-project02.php" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-info-sign"></span> Edit</a>
            <button type="button" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-arrow-right"></span> Checkout</button>
         </div>
         
         */

      ?>
   </div>
</div>    