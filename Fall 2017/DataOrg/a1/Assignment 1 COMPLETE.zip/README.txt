CS3310
Assignment 1
By: Bryan Greener
Written in C# using Visual Studio 2015

HOW TO RUN

1) Navigate to a1/bin/debug/
2) Run a1.exe
3) Enter name and dimensions when prompted
4) An output CIS3310-A1.txt file is saved in this debug folder with the requested information.

Warning:
This program runs each algorithm 1000 times to get an accurate average runtime. Along with that, this program requires a large amount of memory available since it is not optimized. It uses about 1GB of heap at its peak. This program also takes about 3 minutes to run on an i7 with 32GB of RAM. Have fun...