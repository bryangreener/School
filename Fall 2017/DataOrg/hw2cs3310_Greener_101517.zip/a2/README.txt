ASSIGNMENT CONTENTS

Documentation.XML
	Open this .xml file in any browser to view a javadoc style documentation of this assignment and its classes/methods.

Assignment 2 Algorithms Used.docx
	Open this in MS Word to view time complexity analysis and graph showing algorithm run time.

SAMPLE OUTPUT.txt
	Output from running program on my computer.

a2/bin/debug/balancedParenCheckInputs.txt
	Edit this file with input strings. This is the 	main file that the program reads and checks for degree of balanced parentheses. Leave in the bin/debug folder in order for the program to read it.

a2/bin/debug/a2.exe
	Run this program in any windows computer. It will open a command prompt window which will display the results of the parentheses comparison. Close and open again after editing the .txt file with input strings in order for it to re-evaluate the file.

README.txt
	You're already reading this...