INSTRUCTIONS:
Navigate to \a3\bin\Debug\ and run a3.exe to run the program. It will open a command prompt and you will be prompted for user input. Output is displayed right there.
Read folder contents section below for information on other files in the root folder of this program.

FOLDER CONTENTS:
AnalysisData.xlsx
	Excel2016 spreadsheet used to created tables/graphs with empirical data.

Analysis.docx
	Word2016 file with requested analysis of program, time complexities, etc.

Documentation.xml
	Open in brower to view documentation in a Javadoc style display.

SAMPLE OUTPUT.txt
	Text file containing copied output from me running this program on my computer.

a3\bin\Debug\a3.exe
	Run this program from here if you don't have visual studio or some other way to run C# programs.
