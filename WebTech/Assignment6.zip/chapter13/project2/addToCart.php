<?php
require_once('includes/art-config.inc.php');
require_once('lib/ArtistDB.class.php');
require_once('lib/ArtWorkDB.class.php');
require_once('lib/GenreDB.class.php');
require_once('lib/SubjectDB.class.php');
require_once('lib/DatabaseHelper.class.php');

session_start();

$artworkData = new ArtWorkDB();
$item = $artworkData->findById($_SESSION["ArtWorkID"]);

if(isset($_SESSION['ShoppingCart']))
{
    $index = -1;
    foreach($_SESSION['ShoppingCart'] as $key=>$value)
    {
        $res = array_search($item['Title'], $_SESSION['ShoppingCart'][$key]);
        if($res != false)
        {
            $index = $key;
            break;
        }
    }
    if($index == -1)
    {
        $cartArray = array($item["ImageFileName"], $item["Title"], 1, $item["MSRP"]);
        array_push($_SESSION['ShoppingCart'], $cartArray);
    }
    else
    {
        $_SESSION['ShoppingCart'][$key][2] += 1;
        echo $_SESSION['ShoppingCart'][$key][2];
    }
}
else
{
    $_SESSION['ShoppingCart'] = array();
    $cartArray = array($item["ImageFileName"], $item["Title"], 1, $item["MSRP"]);
    array_push($_SESSION['ShoppingCart'], $cartArray);
}



header('Location: display-art-work.php?id=' . $_SESSION["ArtWorkID"]);
?>